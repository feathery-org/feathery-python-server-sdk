API_URL = "http://cdn.feathery.tech/external/"
REQUEST_TIMEOUT = 30
REFRESH_INTERVAL = 60
POLL_FREQ_SECONDS = 60
